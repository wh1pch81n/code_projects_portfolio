Names: 
Gilberto Gamboa SID:860939502 
Derrick Ho SID:860814326
assignment: Lab5


Gilbert worked on the 4KB caches and the C++ mux and decode generator
Derrick worked on the 64 KB caches 


all vhdl components should work.  All of out test bench simulations have worked.