In addition to the controls explained by the in-game help, there are some
additional debugging controls that are fun to play with:

F1: Show collision geometry
F2: Show navigation mesh
F3: Toggle fog and camera far clipping
F4: No clipping (Weee!). Use Page Up/Down to move vertically.
F5: Show rendering information
F6: Show camera and filtering information
F7: Switch filtering modes (None, Bilinear, Trilinear, Anistropic)
F8: Switch poly rendering modes (solid, wireframe, points)
Shift: Run super fast!

It's fun to run really fast through several rooms, getting a few enemies on
your tail along the way, and then quickly stopping and hitting F3 and F8 so
you can see the enemies through the walls navigating their way to you.

You may need to install OpenAL and DirectX. Installers can be found in the
"install" directory.